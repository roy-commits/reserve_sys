create function reservations_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- update reservation_changes
        INSERT INTO rsvp.reservation_changes (reservation_id, old, new, op)
        VALUES (NEW.id, null, to_jsonb(NEW), 'create');
    ELSIF TG_OP = 'UPDATE' THEN
        -- if status changed, update reservation_changes
        IF OLD.status <> NEW.status THEN
            INSERT INTO rsvp.reservation_changes (reservation_id, old, new, op)
            VALUES (NEW.id, to_jsonb(OLD), to_jsonb(NEW), 'update');
        END IF;
    ELSIF TG_OP = 'DELETE' THEN
        -- update reservation_changes
        INSERT INTO rsvp.reservation_changes (reservation_id, old, new, op)
        VALUES (OLD.id, to_jsonb(OLD), null, 'delete');
    END IF;
    -- notify a channel called reservation_update
    NOTIFY reservation_update;
    RETURN NULL;
END;
$$;

alter function reservations_trigger() owner to roy;

